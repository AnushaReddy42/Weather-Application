package com.example.Weather.controller;

import com.example.Weather.model.WeatherResponse;
import com.example.Weather.services.DataService;
import com.example.Weather.services.TimeService;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.client.RestTemplate;

@RestController
@RequestMapping("/weather")
@CrossOrigin(origins = "*")
public class WeatherController {

    private final String API_KEY = "33f226fb7e33bd9eb17ada38dd49f6a5";

    @Autowired
    DataService service;

    @Autowired
    TimeService tservice;

    @GetMapping("/{city}")
    public WeatherResponse gWeatherResponse(@PathVariable String city) {
        String weatherUrl = "https://api.openweathermap.org/data/2.5/weather?q=" + city +
                "&appid=" + API_KEY + "&units=metric";

        try {
            RestTemplate restTemplate = new RestTemplate();
            ResponseEntity<String> weatherResponse = restTemplate.getForEntity(weatherUrl, String.class);

            ObjectMapper mapper = new ObjectMapper();
            JsonNode json = mapper.readTree(weatherResponse.getBody());

            String cityName = json.get("name").asText();
            double temperature = json.get("main").get("temp").asDouble();
            String description = json.get("weather").get(0).get("main").asText().toLowerCase();
            int humidity = json.get("main").get("humidity").asInt();

            int timezoneOffset = json.get("timezone").asInt(); // in seconds

            // Convert timezone offset to region
            String timezone;
            switch (timezoneOffset) {
                case 19800:
                    timezone = "Asia/Kolkata";
                    break;
                case 3600:
                    timezone = "Europe/London";
                    break;
                default:
                    timezone = "Etc/GMT" + (timezoneOffset / 3600);
                    break;
            }

            // Get current time using time API
            String timeApiUrl = "https://timeapi.io/api/Time/current/zone?timeZone=" + timezone;
            ResponseEntity<String> timeResponse = restTemplate.getForEntity(timeApiUrl, String.class);
            JsonNode timeJson = mapper.readTree(timeResponse.getBody());

            String currentTime = timeJson.has("time") ? timeJson.get("time").asText() : "Time not available";

            // Full response with time and timezone
            WeatherResponse weather = new WeatherResponse(cityName, temperature, description, humidity, currentTime, timezoneOffset);
            return weather;

        } catch (Exception e) {
            System.out.println("Error: " + e.getMessage());
            return new WeatherResponse("N/A", 0.0, "error", 0, "Time not available", 0);
        }
    }

    @GetMapping("/data")
    public String getData(@RequestParam String query) {
        return this.service.getData(query);
    }

    @GetMapping("/time")
    public String getTime(@RequestParam String region) {
        return this.tservice.getTime(region);
    }
}
