package com.example.Weather.model;

public class WeatherResponse {
    private String city;
    private double temperature;
    private String description;
    private int humidity;
    private String time;
    private int timezone; // in seconds

    // Constructor without time and timezone
    public WeatherResponse(String city, double temperature, String description, int humidity) {
        this.city = city;
        this.temperature = temperature;
        this.description = description;
        this.humidity = humidity;
    }

    // Constructor with time and timezone
    public WeatherResponse(String city, double temperature, String description, int humidity, String time, int timezone) {
        this.city = city;
        this.temperature = temperature;
        this.description = description;
        this.humidity = humidity;
        this.time = time;
        this.timezone = timezone;
    }

    // Getters
    public String getCity() { return city; }
    public double getTemperature() { return temperature; }
    public String getDescription() { return description; }
    public int getHumidity() { return humidity; }
    public String getTime() { return time; }
    public int getTimezone() { return timezone; }

    // Setters
    public void setTime(String time) { this.time = time; }
    public void setTimezone(int timezone) { this.timezone = timezone; }
}
